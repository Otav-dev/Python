from controllers.figurinhas_controller import figurinhas_bp
app.register_blueprint(figurinhas_bp)

