from datetime import datetime

from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class ModeloBase(db.Model):
    __abstract__ = True

    id = db.Column(db.Integer, primary_key=True)
    data_criacao = db.Column(
        db.DateTime, default=datetime.now, nullable=False
    )
    data_atualizacao = db.Column(
        db.DateTime,
        default=datetime.now,
        onupdate=datetime.now,
        nullable=False,
    )


# =============================================================================
# TODO ALUNO: crie pelo menos 3 tabelas abaixo, todas herdando ModeloBase
# Use db.ForeignKey("nome_tabela.id") para ligar as tabelas
# Use db.relationship() para navegar entre elas
# =============================================================================


class Tabela1(ModeloBase):
    """Representa o Colecionador"""
    __tablename__ = "colecionadores"
    
    apelido = db.Column(db.String(60), nullable=False)
    cidade = db.Column(db.String(80), nullable=False)

    ofertas = db.relationship("Tabela2", backref="colecionador", lazy=True)


class Tabela2(ModeloBase):
    """Representa a OfertaTroca"""
    __tablename__ = "ofertas_troca"
    
    tabela1_id = db.Column(db.Integer, db.ForeignKey("colecionadores.id"), nullable=False)
    observacao = db.Column(db.String(255), nullable=True)

    itens = db.relationship("Tabela3", backref="oferta", lazy=True, cascade="all, delete-orphan")


class Tabela3(ModeloBase):
    """Representa o ItemOferta"""
    __tablename__ = "itens_oferta"
    
    tabela1_id = db.Column(db.Integer, db.ForeignKey("colecionadores.id"), nullable=False)
    tabela2_id = db.Column(db.Integer, db.ForeignKey("ofertas_troca.id"), nullable=False)
    
    tipo = db.Column(db.String(20), nullable=False)  
    quantidade = db.Column(db.Integer, nullable=False, default=1)

    pass

