from .figurinhas_controller import figurinhas_bp
from .dashboard_controller import dashboard_bp
from .clientes_controller import clientes_bp
from .pedidos_controller import pedidos_bp

__all__ = ["dashboard_bp", "figurinhas_bp", "clientes_bp", "pedidos_bp"]
