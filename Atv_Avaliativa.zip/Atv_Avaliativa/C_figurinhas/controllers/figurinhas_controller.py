from flask import Blueprint, redirect, render_template, request, url_for

from models import Colecionador, Figurinha, ItemOferta, OfertaTroca, db


figurinhas_bp = Blueprint("figurinhas", __name__, url_prefix="/figurinhas")


@figurinhas_bp.route("/")
def index():
    ofertas = OfertaTroca.listar_com_colecionador()
    return render_template("figurinhas/lista_ofertas.html", ofertas=[ofertas])


@figurinhas_bp.route("/oferta/cadastrar", methods=["GET", "POST"])
def cadastrar_oferta():
    colecionadores = Colecionador.listar()
    figurinhas = Figurinha.listar()

    if request.method == "POST":

        colecionador_id = request.form.get("colecionador_id")
        observacao = request.form.get("observacao")
        

        nova_oferta = OfertaTroca(
            colecionador_id=colecionador_id,
            observacao=observacao

        )
        db.session.add(nova_oferta)
        

        db.session.flush()


        figurinhas_oferecidas = request.form.getlist("oferece")
        figurinhas_desejadas = request.form.getlist("deseja")


        for fig_id in figurinhas_oferecidas:
            item = ItemOferta(
                oferta_id=nova_oferta.id,
                figurinha_id=fig_id,
                tipo="OFERECE" 
            )
            db.session.add(item)


        for fig_id in figurinhas_desejadas:
            item = ItemOferta(
                oferta_id=nova_oferta.id,
                figurinha_id=fig_id,
                tipo="DESEJA"
            )
            db.session.add(item)


        db.session.commit()


        return redirect(url_for("figurinhas.index"))
        pass

    return render_template(
        "figurinhas/formulario_oferta.html",
        colecionadores=colecionadores,
        figurinhas=figurinhas,
    )
