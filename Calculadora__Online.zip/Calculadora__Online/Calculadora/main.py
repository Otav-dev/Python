import funcao_calculadora

funcao_calculadora.calculadora()