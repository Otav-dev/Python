
def divisao(a, b):
    if b == 0:
        print("Não pode fazer divisão por zero")
     
    else:
        dividir = a / b
        return dividir
        

