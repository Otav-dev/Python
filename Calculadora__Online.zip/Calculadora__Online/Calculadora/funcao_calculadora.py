import divisao 
import multiplicar
import soma
import subtrair
import raizquadrada
import potencia
import cambiodolar
import pandas as pd

def calculadora():

    
    print("Qual operação deseja realizar:")
    print("1. Soma")
    print("2. Subtração")
    print("3. Multiplicação")
    print("4. Divisão")
    print("5. Potência")
    print("6. Raiz quadrada")
    print("7. Cotação dólar")

    while True:  
        opcao = float(input("Digite o número da operação: "))
        if opcao == 1:
          print("Insira os valores:")
          a = float(input("Digite o primeiro valor: "))
          b = float(input("Digite o segundo valor: "))
          resultado = soma.somar(a, b)
          print(resultado)
        elif opcao == 2:
          print("Insira os valores:")
          a = float(input("Digite o primeiro valor: "))
          b = float(input("Digite o segundo valor: "))
          resultado = subtrair.subtracao(a, b)
          print(resultado)
        elif opcao == 3:
          print("Insira os valores:")
          a = float(input("Digite o primeiro valor: "))
          b = float(input("Digite o segundo valor: "))
          resultado = multiplicar.multiplicar(a, b)
          print(resultado)  
        elif opcao == 4:
          print("Insira os valores:")
          a = float(input("Digite o primeiro valor: "))
          b = float(input("Digite o segundo valor: "))
          resultado = divisao.divisao(a, b)
          print(resultado)  
        elif opcao == 5:
          print("Insira os valores:")
          a = float(input("Digite o primeiro valor: "))
          b = float(input("Digite o segundo valor: "))
          resultado = potencia.potencia(a, b)
          print(resultado)
        elif opcao == 6:
          print("Insira os valores:")
          a = float(input("Digite o valor: "))
          resultado = raizquadrada.raizquadrada(a)
          print(resultado)  
        elif opcao == 7:
            print(f"A cotação do dolar hoje está em: {cambiodolar.cotacao_dolar()}")
            dolar = input("Deseja converter o real para dolar? (S/N)").strip().upper()
            valor = int(input("Digite o valor desejado: "))
            dolar_preco = cambiodolar.cotacao_dolar()
            resultado = valor / dolar_preco
            print(f"Valor em dolar é igual a {resultado}! ")
                
        else:
         print("Não existe essa opção")   
         break




   


