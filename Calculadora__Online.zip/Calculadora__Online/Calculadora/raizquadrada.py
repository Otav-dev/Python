import math

def raizquadrada(a):
    raiz = math.sqrt(a)
    return raiz
