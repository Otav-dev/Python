def potencia(a, b):
    potencia = a ** b
    return potencia
