import os
from flask import Flask, redirect, url_for, session
from models import db

def criar_app():
    app = Flask(
        __name__,
        template_folder="templates",
        static_folder="static"
    )
    
    app.config["SECRET_KEY"] = "sua_chave_secreta_aqui"

    pasta = os.path.abspath(os.path.dirname(__file__))
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(pasta, "painel_controle.db")
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    db.init_app(app)

    with app.app_context():
        db.create_all()

    # Importação e Registro dos Blueprints
    from controllers.auth import auth_bp
    from controllers.dashboard import dashboard_bp
    from controllers.tarefas import tarefas_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(tarefas_bp)

    # Rota Raiz (acesso direto a http://127.0.0.1:5000/)
    @app.route('/')
    def root():
        if session.get('usuario_id'):
            return redirect(url_for('dashboard.index'))
        return redirect(url_for('auth.login'))

    return app

app = criar_app()

if __name__ == "__main__":
    app.run(debug=True)