from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import func
from models import db, usuario

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/registro', methods=['GET', 'POST'])
def registro():
    if request.method == 'POST':
        nome = request.form.get('nome').strip()
        email = request.form.get('email').strip()
        senha = request.form.get('senha')

        senha_hash = generate_password_hash(senha)
        novo_usuario = usuario(nome=nome, email=email, senha=senha_hash)
        
        try:
            db.session.add(novo_usuario)
            db.session.commit()
            flash('Cadastro realizado com sucesso! Faça seu login.')
            return redirect(url_for('auth.login'))
        except Exception as e:
            db.session.rollback()
            flash('Erro ao cadastrar. Verifique se o e-mail ou nome já existem.')
            return redirect(url_for('auth.registro'))

    return render_template('registro.html')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        nome_digitado = request.form.get('nome').strip()
        senha_digitada = request.form.get('senha')

        # Busca o usuário ignorando maiúsculas e minúsculas
        user = usuario.query.filter(func.lower(usuario.nome) == func.lower(nome_digitado)).first()

        if user and check_password_hash(user.senha, senha_digitada):
            session['usuario_id'] = user.id
            return redirect(url_for('dashboard.index'))
        else:
            flash('Nome de usuário ou senha incorretos.')
            return redirect(url_for('auth.login'))

    return render_template('login.html')

@auth_bp.route('/logout')
def logout():
    session.pop('usuario_id', None)
    return redirect(url_for('auth.login'))