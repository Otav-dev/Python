from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from models import db, tarefas

# Criando o Blueprint das tarefas
tarefas_bp = Blueprint('tarefas', __name__)

@tarefas_bp.route('/nova', methods=['GET', 'POST'])
def nova():
    if not session.get('usuario_id'):
        return redirect(url_for('auth.login'))

    if request.method == 'POST':
        titulo = request.form.get('titulo')
        descricao = request.form.get('descricao')
        status = request.form.get('status')
        usuario_id = session.get('usuario_id')

        # Cria a tarefa no banco de dados
        nova_tarefa = tarefas(titulo=titulo, descricao=descricao, status=status, usuario_id=usuario_id)
        db.session.add(nova_tarefa)
        db.session.commit()

        flash('Tarefa criada com sucesso!')
        return redirect(url_for('dashboard.index'))

    # Aponta para templates/tarefas/nova_tarefa.html
    return render_template('tarefas/nova_tarefa.html')

@tarefas_bp.route('/editar/<int:id>', methods=['GET', 'POST'])
def editar(id):
    if not session.get('usuario_id'):
        return redirect(url_for('auth.login'))

    tarefa = tarefas.query.get_or_404(id)

    # Garante que o usuário só pode editar as suas próprias tarefas
    if tarefa.usuario_id != session.get('usuario_id'):
        flash('Acesso negado!')
        return redirect(url_for('dashboard.index'))

    if request.method == 'POST':
        tarefa.titulo = request.form.get('titulo')
        tarefa.descricao = request.form.get('descricao')
        tarefa.status = request.form.get('status')
        
        db.session.commit()
        flash('Tarefa atualizada com sucesso!')
        return redirect(url_for('dashboard.index'))

    # Aponta para templates/tarefas/editar_tarefa.html
    return render_template('tarefas/editar_tarefa.html', tarefa=tarefa)

@tarefas_bp.route('/excluir/<int:id>')
def excluir(id):
    if not session.get('usuario_id'):
        return redirect(url_for('auth.login'))

    tarefa = tarefas.query.get_or_404(id)

    if tarefa.usuario_id == session.get('usuario_id'):
        db.session.delete(tarefa)
        db.session.commit()
        flash('Tarefa excluída com sucesso!')

    return redirect(url_for('dashboard.index'))