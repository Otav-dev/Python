from flask import Blueprint, render_template, redirect, url_for, session, jsonify
from models import db, tarefas, usuario
import requests

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/dashboard')
def index():
    if not session.get('usuario_id'):
        return redirect(url_for('auth.login'))

    usuario_id = session.get('usuario_id')
    user_logado = usuario.query.get(usuario_id)

    frase_motivacional = "Mantenha o foco e organize o seu dia!"
    try:
        resposta = requests.get("https://api.adviceslip.com/advice", timeout=3)
        if resposta.status_code == 200:
            frase_motivacional = resposta.json()["slip"]["advice"]
    except Exception:
        pass

    return render_template(
        'dashboard.html',
        user=user_logado,
        frase=frase_motivacional
    )

@dashboard_bp.route('/api/tarefas/<status>', methods=['GET'])
def api_filtrar_tarefas(status):
    if not session.get('usuario_id'):
        return jsonify({'erro': 'Não autorizado'}), 401

    usuario_id = session.get('usuario_id')

    if status == 'todas':
        lista = tarefas.query.filter_by(usuario_id=usuario_id).all()
    else:
        lista = tarefas.query.filter_by(usuario_id=usuario_id, status=status).all()

    resultado = []
    for t in lista:
        resultado.append({
            'id': t.id,
            'titulo': t.titulo,
            'descricao': t.descricao,
            'status': t.status
        })

    return jsonify(resultado)

@dashboard_bp.route('/api/progresso-tarefas', methods=['GET'])
def api_progresso_tarefas():
    if not session.get('usuario_id'):
        return jsonify({'erro': 'Não autorizado'}), 401

    usuario_id = session.get('usuario_id')

    # Conta as tarefas agrupadas por status para o usuário logado
    pendentes = tarefas.query.filter_by(usuario_id=usuario_id, status='Pendente').count()
    em_andamento = tarefas.query.filter_by(usuario_id=usuario_id, status='Em andamento').count()
    concluidas = tarefas.query.filter_by(usuario_id=usuario_id, status='Concluída').count()

    dados = {
        'labels': ['Pendente', 'Em andamento', 'Concluída'],
        'valores': [pendentes, em_andamento, concluidas]
    }

    return jsonify(dados)

# Rota para renderizar a página do Dashboard de Progresso
@dashboard_bp.route('/dashboard/progresso')
def progresso_visual():
    if not session.get('usuario_id'):
        return redirect(url_for('auth.login'))
    
    usuario_id = session.get('usuario_id')
    user_logado = usuario.query.get(usuario_id)
    
    return render_template('progresso.html', user=user_logado)