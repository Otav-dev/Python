from . import db
from .base import ModeloBase

class tarefas(ModeloBase):
    __tablename__ = "Tarefas"

    titulo = db.Column(db.String(120), nullable=False)
    descricao = db.Column(db.String(120), nullable=False)
    status = db.Column(db.String(50), default="Pendente", nullable=False) # Alterado para String
    usuario_id = db.Column(db.Integer, db.ForeignKey('Usuario.id'), nullable=False)