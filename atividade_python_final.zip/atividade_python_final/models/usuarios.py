from . import db
from .base import ModeloBase

class usuario(ModeloBase):
    __tablename__ = "Usuario"

    nome = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    senha = db.Column(db.String(255), nullable=False)