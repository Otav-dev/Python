from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

from .base import ModeloBase
from .tarefas import tarefas
from .usuarios import usuario


__all__ = ["db", "ModeloBase", "Tarefas","Usuario"]